-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server Version:               5.6.14 - MySQL Community Server (GPL)
-- Server Betriebssystem:        Win32
-- HeidiSQL Version:             8.3.0.4694
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle world.aowow_account
CREATE TABLE IF NOT EXISTS `aowow_account` (
  `id` int(16) NOT NULL,
  `authId` int(11) NOT NULL COMMENT 'WoW Uid',
  `user` varchar(64) NOT NULL COMMENT 'login',
  `passHash` varchar(128) NOT NULL COMMENT 'sha1 for wow; bCrypt for internal use',
  `displayName` varchar(64) NOT NULL COMMENT 'Nickname',
  `email` varchar(64) NOT NULL,
  `joindate` bigint(20) NOT NULL COMMENT 'unixtime',
  `lastIP` varchar(15) NOT NULL,
  `lastLogin` bigint(20) NOT NULL COMMENT 'unixtime',
  `timeout` bigint(20) NOT NULL COMMENT 'session timeout unixtime',
  `locale` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0,2,3,6,8',
  `userGroups` bigint(20) NOT NULL DEFAULT '0' COMMENT 'bitmask',
  `avatar` varchar(16) NOT NULL COMMENT 'icon-string for internal or id for upload',
  `description` text NOT NULL COMMENT 'markdown formated',
  `userPerms` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'bool isAdmin',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_account_banned
CREATE TABLE IF NOT EXISTS `aowow_account_banned` (
  `id` int(16) NOT NULL,
  `banDate` bigint(20) NOT NULL COMMENT 'unixtime',
  `banReason` varchar(256) NOT NULL,
  `unbanDate` bigint(20) NOT NULL DEFAULT '-1' COMMENT 'automatic unban @ unixtime',
  `bannedBy` int(11) NOT NULL COMMENT 'aowow UId',
  `isActive` tinyint(4) NOT NULL DEFAULT '1' COMMENT 'bool',
  `restrictions` smallint(6) NOT NULL DEFAULT '0' COMMENT 'bitmask x1: comment; x2: upload; x4: rate',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_account_bannedips
CREATE TABLE IF NOT EXISTS `aowow_account_bannedips` (
  `ip` varchar(15) NOT NULL,
  `count` smallint(6) NOT NULL COMMENT 'num loginFails',
  `type` tinyint(4) NOT NULL COMMENT '0: onSignin; 1:onSignup',
  `unbanDate` bigint(20) NOT NULL COMMENT 'automatic remove @ unixtime'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_account_cookies
CREATE TABLE IF NOT EXISTS `aowow_account_cookies` (
  `userId` int(10) unsigned NOT NULL,
  `name` varchar(127) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `userId_name` (`userId`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_account_weightscales
CREATE TABLE IF NOT EXISTS `aowow_account_weightscales` (
  `id` int(32) NOT NULL,
  `account` int(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `weights` text NOT NULL,
  PRIMARY KEY (`id`,`account`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_comments
CREATE TABLE IF NOT EXISTS `aowow_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Comment ID',
  `type` int(10) unsigned NOT NULL COMMENT 'Type of Page',
  `typeid` int(10) unsigned NOT NULL COMMENT 'ID Of Page',
  `userid` bigint(20) unsigned NOT NULL COMMENT 'User ID',
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Comment timestap',
  `commentbody` text COMMENT 'Comment text',
  `replyto` bigint(20) unsigned DEFAULT NULL COMMENT 'Reply To, comment ID',
  `edit_userid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Last Edit User ID',
  `edit_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT 'Last Edit Time',
  `edit_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Count Of Edits',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='AoWoW Comments Table';

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_comments_rates
CREATE TABLE IF NOT EXISTS `aowow_comments_rates` (
  `commentid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Comment ID',
  `userid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'User ID',
  `rate` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Rating Set'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='AoWoW Comments Rates Table';

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_screenshots
CREATE TABLE IF NOT EXISTS `aowow_screenshots` (
  `id` int(16) NOT NULL,
  `type` int(8) NOT NULL,
  `typeId` int(32) NOT NULL,
  `uploader` int(16) NOT NULL,
  `date` int(32) NOT NULL,
  `width` int(16) NOT NULL,
  `height` int(16) NOT NULL,
  `caption` text,
  `status` int(8) NOT NULL COMMENT '0x1: justUploaded; 0x2: approved; 0x4: sticky; 0x8: purged; 0x10: deleted',
  `approvedBy` int(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`typeId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_videos
CREATE TABLE IF NOT EXISTS `aowow_videos` (
  `id` int(16) NOT NULL,
  `type` int(8) NOT NULL,
  `typeId` int(16) NOT NULL,
  `uploader` int(16) NOT NULL,
  `date` int(32) NOT NULL,
  `videoId` varchar(12) NOT NULL,
  `caption` text,
  `status` int(8) NOT NULL,
  `approvedBy` int(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`typeId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
