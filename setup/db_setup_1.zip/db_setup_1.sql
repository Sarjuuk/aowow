-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server Version:               5.6.16 - MySQL Community Server (GPL)
-- Server Betriebssystem:        Win32
-- HeidiSQL Version:             8.3.0.4796
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Exportiere Struktur von Tabelle world.aowow_account
DROP TABLE IF EXISTS `aowow_account`;
CREATE TABLE IF NOT EXISTS `aowow_account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `extId` int(10) unsigned NOT NULL COMMENT 'external user id',
  `user` varchar(64) NOT NULL COMMENT 'login',
  `passHash` varchar(128) NOT NULL,
  `displayName` varchar(64) NOT NULL COMMENT 'nickname',
  `email` varchar(64) NOT NULL,
  `joinDate` int(10) unsigned NOT NULL COMMENT 'unixtime',
  `allowExpire` tinyint(1) unsigned NOT NULL,
  `dailyVotes` smallint(5) unsigned NOT NULL DEFAULT '0',
  `consecutiveVisits` smallint(5) unsigned NOT NULL DEFAULT '0',
  `curIP` varchar(15) NOT NULL,
  `prevIP` varchar(15) NOT NULL,
  `curLogin` int(10) unsigned NOT NULL COMMENT 'unixtime',
  `prevLogin` int(10) unsigned NOT NULL,
  `locale` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '0,2,3,6,8',
  `userGroups` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'bitmask',
  `avatar` varchar(16) NOT NULL DEFAULT '' COMMENT 'icon-string for internal or id for upload',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT 'user can obtain custom titles',
  `description` text NOT NULL COMMENT 'markdown formated',
  `userPerms` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'bool isAdmin',
  `status` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT 'flag, see defines',
  `statusTimer` int(10) unsigned NOT NULL DEFAULT '0',
  `token` varchar(40) NOT NULL COMMENT 'creation & recovery',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_account_banned
DROP TABLE IF EXISTS `aowow_account_banned`;
CREATE TABLE IF NOT EXISTS `aowow_account_banned` (
  `id` int(16) unsigned NOT NULL,
  `userId` int(11) unsigned NOT NULL COMMENT 'affected accountId',
  `staffId` int(11) unsigned NOT NULL COMMENT 'executive accountId',
  `typeMask` tinyint(4) unsigned NOT NULL COMMENT 'ACC_BAN_*',
  `start` int(10) unsigned NOT NULL COMMENT 'unixtime',
  `end` int(10) unsigned NOT NULL COMMENT 'automatic unban @ unixtime',
  `reason` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_account_bannedips
DROP TABLE IF EXISTS `aowow_account_bannedips`;
CREATE TABLE IF NOT EXISTS `aowow_account_bannedips` (
  `ip` varchar(15) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '0: onSignin; 1:onSignup',
  `count` smallint(6) NOT NULL COMMENT 'nFails',
  `unbanDate` int(11) NOT NULL COMMENT 'automatic remove @ unixtime',
  PRIMARY KEY (`ip`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_account_cookies
DROP TABLE IF EXISTS `aowow_account_cookies`;
CREATE TABLE IF NOT EXISTS `aowow_account_cookies` (
  `userId` int(10) unsigned NOT NULL,
  `name` varchar(127) NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`userId`),
  UNIQUE KEY `userId_name` (`userId`,`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_account_reputation
DROP TABLE IF EXISTS `aowow_account_reputation`;
CREATE TABLE IF NOT EXISTS `aowow_account_reputation` (
  `userId` int(10) unsigned NOT NULL,
  `action` tinyint(3) unsigned NOT NULL COMMENT 'e.g. upvote a comment',
  `amount` tinyint(3) unsigned NOT NULL,
  `sourceA` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'e.g. upvoting user',
  `sourceB` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'e.g. upvoted commentId',
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `userId_action_source` (`userId`,`action`,`sourceA`,`sourceB`),
  KEY `userId` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='reputation log';

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_account_weightscales
DROP TABLE IF EXISTS `aowow_account_weightscales`;
CREATE TABLE IF NOT EXISTS `aowow_account_weightscales` (
  `id` int(32) NOT NULL AUTO_INCREMENT,
  `account` int(32) NOT NULL,
  `name` varchar(32) NOT NULL,
  `weights` text NOT NULL,
  PRIMARY KEY (`id`,`account`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_comments
DROP TABLE IF EXISTS `aowow_comments`;
CREATE TABLE IF NOT EXISTS `aowow_comments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Comment ID',
  `type` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Type of Page',
  `typeId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'ID Of Page',
  `userId` int(10) unsigned NOT NULL COMMENT 'User ID',
  `roles` smallint(5) unsigned NOT NULL,
  `body` text NOT NULL COMMENT 'Comment text',
  `date` int(11) NOT NULL COMMENT 'Comment timestap',
  `flags` smallint(6) NOT NULL DEFAULT '0' COMMENT 'deleted, outofdate, sticky',
  `replyTo` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Reply To, comment ID',
  `editUserId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Last Edit User ID',
  `editDate` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Last Edit Time',
  `editCount` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Count Of Edits',
  `deleteUserId` int(10) unsigned NOT NULL DEFAULT '0',
  `deleteDate` int(10) unsigned NOT NULL DEFAULT '0',
  `responseUserId` int(10) unsigned NOT NULL DEFAULT '0',
  `responseBody` text,
  `responseRoles` smallint(5) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='AoWoW Comments Table';

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_comments_rates
DROP TABLE IF EXISTS `aowow_comments_rates`;
CREATE TABLE IF NOT EXISTS `aowow_comments_rates` (
  `commentId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Comment ID',
  `userId` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'User ID',
  `value` tinyint(4) NOT NULL DEFAULT '0' COMMENT 'Rating Set',
  PRIMARY KEY (`commentId`,`userId`),
  UNIQUE KEY `commentId_userId` (`commentId`,`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='AoWoW Comments Rates Table';

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_reports
DROP TABLE IF EXISTS `aowow_reports`;
CREATE TABLE IF NOT EXISTS `aowow_reports` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `userId` mediumint(8) unsigned NOT NULL,
  `assigned` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '0:new; 1:solved; 2:rejected',
  `mode` tinyint(3) unsigned NOT NULL,
  `reason` tinyint(3) unsigned NOT NULL,
  `subject` mediumint(9) NOT NULL DEFAULT '0',
  `ip` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `userAgent` varchar(255) NOT NULL,
  `appName` varchar(32) NOT NULL,
  `url` varchar(255) NOT NULL,
  `relatedUrl` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_screenshots
DROP TABLE IF EXISTS `aowow_screenshots`;
CREATE TABLE IF NOT EXISTS `aowow_screenshots` (
  `id` int(16) NOT NULL,
  `type` int(8) NOT NULL,
  `typeId` int(32) NOT NULL,
  `uploader` int(16) NOT NULL,
  `date` int(32) NOT NULL,
  `width` int(16) NOT NULL,
  `height` int(16) NOT NULL,
  `caption` text,
  `status` int(8) NOT NULL COMMENT '0x1: justUploaded; 0x2: approved; 0x4: sticky; 0x8: purged; 0x10: deleted',
  `approvedBy` int(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`typeId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_spawns
DROP TABLE IF EXISTS `aowow_spawns`;
CREATE TABLE IF NOT EXISTS `aowow_spawns` (
  `guid` int(11) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `typeId` int(10) unsigned NOT NULL,
  `respawn` int(10) unsigned NOT NULL COMMENT 'in seconds',
  `spawnMask` tinyint(3) unsigned NOT NULL,
  `phaseMask` smallint(5) unsigned NOT NULL,
  `mapId` smallint(5) unsigned NOT NULL COMMENT 'maybe this can be dropped',
  `areaId` smallint(5) unsigned NOT NULL,
  `floor` tinyint(3) unsigned NOT NULL,
  `posX` float unsigned NOT NULL,
  `posY` float unsigned NOT NULL,
  PRIMARY KEY (`guid`,`type`),
  KEY `type_idx` (`typeId`,`type`),
  KEY `zone_idx` (`areaId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt


-- Exportiere Struktur von Tabelle world.aowow_videos
DROP TABLE IF EXISTS `aowow_videos`;
CREATE TABLE IF NOT EXISTS `aowow_videos` (
  `id` int(16) NOT NULL,
  `type` int(8) NOT NULL,
  `typeId` int(16) NOT NULL,
  `uploader` int(16) NOT NULL,
  `date` int(32) NOT NULL,
  `videoId` varchar(12) NOT NULL,
  `caption` text,
  `status` int(8) NOT NULL,
  `approvedBy` int(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`,`typeId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- Daten Export vom Benutzer nicht ausgewählt
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
